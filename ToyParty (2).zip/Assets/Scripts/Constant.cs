using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Constant : MonoBehaviour
{
    public const string LAYER_NAME_GEM = "Gem";

    public const string LAYER_NAME_HEXAGON = "Hexagon";
}
