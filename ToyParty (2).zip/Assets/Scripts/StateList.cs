public enum StageList
{
    Setting,
    Selecting,
    Moving
}
